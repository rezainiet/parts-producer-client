# Parts Producer website details

Live website link [Parts Producer](https://parts-producer.web.app/).

## Short Description: 
This is a simple website made with `React`, `firebase`, `react router`, `node`, `express`, `mongodb`, `mongodb` etc. Anyone can signup and login in this website. after login they can submit any order. and they can update their info from dashboard > My Profile route.
and they can review in this website. if any orders payment is not completed user can cancel(delete)  his/her order.
and when click onb pay button from my orders page he/she will redirect in another page for pay with card.


## Features: 
- User can sign up with email and password.
- They can login with email password based authentication also google sign in method implemented.
- User can see 3 items in the homepage and all of the items in manage inventory route.
- Logged in user can order product.
- Logged in user can see which product he was ordered and they can see transaction id when he/she paid for that order/orders.
- When user wants to delete his/her order a confirmation dialogue box will open and when click on ok the product will delete otherwise not.
- Logged in user can update their info from dashboard>my profile.
- if an admin login he/she will see manage orders, add a product, manage users, make admin options. etc.